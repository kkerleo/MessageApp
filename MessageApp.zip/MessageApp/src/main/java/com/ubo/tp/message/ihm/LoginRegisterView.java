package main.java.com.ubo.tp.message.ihm;

import javax.swing.*;
import java.awt.*;

public class LoginRegisterView {
    protected JFrame mFrame;
    public LoginRegisterView(JFrame mFrame){
        mFrame = mFrame;

    }
    protected void connexionInscriptionUI() {
        Dimension dimension = new Dimension(400, 200);
        ImageIcon imageIcon = new ImageIcon("src/main/resources/images/logo_20.png");

        mFrame = new JFrame("Connexion/Inscription");
        mFrame.setPreferredSize(dimension);
        mFrame.setIconImage(imageIcon.getImage());

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 240, 240)); // Couleur de fond

        JButton loginButton = createStyledButton("Connexion", new Color(70, 130, 180));
        loginButton.addActionListener(e -> connexionUI());

        JButton registerButton = createStyledButton("Inscription", new Color(70, 130, 180));
        registerButton.addActionListener(e -> inscriptionUI());

        panel.add(loginButton, new GridBagConstraints(0, 0, 1, 1, 1, 1, GridBagConstraints.CENTER,
                GridBagConstraints.NONE, new Insets(0, 0, 10, 5), 0, 0));
        panel.add(registerButton, new GridBagConstraints(1, 0, 1, 1, 1, 1, GridBagConstraints.CENTER,
                GridBagConstraints.NONE, new Insets(0, 5, 10, 0), 0, 0));

        mFrame.add(panel);
        mFrame.setLocationRelativeTo(null);
        mFrame.pack();
        mFrame.setVisible(true);
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 16)); // Réduire la taille de la police
        button.setPreferredSize(new Dimension(150, 50));
        // Ajouter des bordures arrondies pour un aspect plus moderne
        button.setBorder(BorderFactory.createLineBorder(new Color(70, 130, 180), 2, true));
        return button;
    }

    protected void connexionUI(){
        mFrame.getContentPane().removeAll();
//        mFrame.add(new ConnexionView());
        mFrame.revalidate();
        mFrame.repaint();
    }

    protected void inscriptionUI(){
        mFrame.getContentPane().removeAll();
        mFrame.add(new InscriptionView(this.mFrame));
        mFrame.revalidate();
        mFrame.repaint();
    }
}
