package main.java.com.ubo.tp.message.ihm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ConnexionView extends JPanel {

    protected JFrame jFrame;
    protected JTextField username;
    protected JTextField tag;
    protected JLabel messageLabel;
    protected JButton connexionButton;
    protected JButton inscriptionButton;

    public ConnexionView(JFrame mFrame) {
        jFrame = mFrame;
        ImageIcon imageIcon = new ImageIcon("src/main/resources/images/logo_20.png");

        mFrame.setTitle("Connexion/Inscription");
        mFrame.setIconImage(imageIcon.getImage());
        mFrame.setSize(500, 300);
        mFrame.setLocationRelativeTo(null);
        mFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mFrame.setLayout(new GridBagLayout());

        JPanel connexionPanel = new JPanel();
        connexionPanel.setLayout(new GridBagLayout());
        connexionPanel.setBorder(BorderFactory.createTitledBorder("Connexion/Inscription"));
        connexionPanel.setBackground(new Color(240, 240, 240));

        JLabel usernameLabel = new JLabel("Nom d'utilisateur", SwingConstants.RIGHT);
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        connexionPanel.add(usernameLabel, new GridBagConstraints(0, 0, 1, 1, 1, 1, GridBagConstraints.EAST,
                GridBagConstraints.NONE, new Insets(10, 10, 0, 0), 0, 0));

        JLabel tagLabel = new JLabel("Tag", SwingConstants.RIGHT);
        tagLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        connexionPanel.add(tagLabel, new GridBagConstraints(0, 1, 1, 1, 1, 1, GridBagConstraints.EAST,
                GridBagConstraints.NONE, new Insets(0, 10, 0, 0), 0, 0));

        username = new JTextField(20);
        connexionPanel.add(username, new GridBagConstraints(1, 0, 1, 1, 1, 1, GridBagConstraints.WEST,
                GridBagConstraints.NONE, new Insets(10, 0, 0, 10), 0, 0));

        tag = new JTextField(20);
        connexionPanel.add(tag, new GridBagConstraints(1, 1, 1, 1, 1, 1, GridBagConstraints.WEST,
                GridBagConstraints.NONE, new Insets(0, 0, 0, 10), 0, 0));

        connexionButton = new JButton("Se connecter");
        connexionButton.setBackground(new Color(30, 144, 255));
        connexionButton.setForeground(Color.WHITE);
        connexionButton.setFont(new Font("Arial", Font.BOLD, 14));
        connexionPanel.add(connexionButton, new GridBagConstraints(0, 2, 2, 1, 1, 1, GridBagConstraints.CENTER,
                GridBagConstraints.NONE, new Insets(10, 0, 0, 0), 0, 0));

        inscriptionButton = new JButton("S'inscrire");
        inscriptionButton.setBackground(new Color(60, 179, 113));
        inscriptionButton.setForeground(Color.WHITE);
        inscriptionButton.setFont(new Font("Arial", Font.BOLD, 14));
        connexionPanel.add(inscriptionButton, new GridBagConstraints(1, 2, 2, 1, 1, 1, GridBagConstraints.CENTER,
                GridBagConstraints.NONE, new Insets(10, 10, 0, 0), 0, 0));

        messageLabel = new JLabel("", SwingConstants.CENTER);
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        connexionPanel.add(messageLabel, new GridBagConstraints(0, 3, 2, 1, 1, 1, GridBagConstraints.CENTER,
                GridBagConstraints.NONE, new Insets(10, 0, 0, 0), 0, 0));

        mFrame.add(connexionPanel);
        mFrame.setVisible(true);
    }

    public void loginOnClick(ConnexionListener connexionListener) {
        connexionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                connexionListener.loginOnClick(username.getText(), tag.getText());
            }
        });
    }

    public void registerOnClick(ConnexionListener connexionListener) {
        inscriptionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                connexionListener.RegisterOnClick(username.getText(), tag.getText());
            }
        });
    }

    public void destroy() {
        jFrame.dispose();
        jFrame.getContentPane().removeAll();
        jFrame.revalidate();
        jFrame.repaint();
    }

    public interface ConnexionListener {
        void loginOnClick(String username, String tag);

        void RegisterOnClick(String username, String tag);
    }
}
