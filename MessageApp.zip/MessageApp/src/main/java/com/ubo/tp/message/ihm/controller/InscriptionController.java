package main.java.com.ubo.tp.message.ihm.controller;

import main.java.com.ubo.tp.message.core.EntityManager;
import main.java.com.ubo.tp.message.core.database.IDatabase;
import main.java.com.ubo.tp.message.datamodel.User;
import main.java.com.ubo.tp.message.ihm.ConnexionView;
import main.java.com.ubo.tp.message.ihm.session.ISession;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

public class InscriptionController implements ConnexionView.ConnexionListener {

    protected IDatabase database;
    protected EntityManager entityManager;
    protected ISession session;
    protected boolean doUserExists = false;


    public InscriptionController(ConnexionView connexionView, IDatabase database, EntityManager entityManager, ISession session){
        connexionView.registerOnClick(this);
        this.database = database;
        this.entityManager = entityManager;
        this.session = session;
    }

    @Override
    public void RegisterOnClick(String username, String tag) {
        initFolder();

        User user = new User(UUID.randomUUID(), tag, "password", username, new HashSet<>(), "avatar");

        for(User u : database.getUsers()){
            if(Objects.equals(u.getUserTag(), user.getUserTag())){
                System.out.println("oui");
                doUserExists = true;
                break;
            }
        }

        if(isUsernameNull(username) || isTagNull(tag)) {
            System.out.println("Veuillez remplir les champs d'inscription");
        } else if(doUserExists) {
            System.out.println("Le tag rentré est déjà associé à un compte existant");
        } else {
            database.addUser(user);
            entityManager.writeUserFile(user);
            System.out.println("Inscription réussie, vous pouvez maintenant vous connecter");
        }
    }


    public boolean isUsernameNull(String username){
        return username == null || username.isEmpty();
    }

    public boolean isTagNull(String tag){
        return tag == null || tag.isEmpty();
    }

    public void initFolder(){
        entityManager.setExchangeDirectory("src/main/resources/users/");
    }

    public Set<User> getUsersRegistered(){
        return database.getUsers();
    }

    @Override
    public void loginOnClick(String username, String tag) {
    }


}