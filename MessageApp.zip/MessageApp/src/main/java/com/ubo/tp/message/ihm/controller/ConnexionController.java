package main.java.com.ubo.tp.message.ihm.controller;

import main.java.com.ubo.tp.message.core.EntityManager;
import main.java.com.ubo.tp.message.core.database.IDatabase;
import main.java.com.ubo.tp.message.datamodel.User;
import main.java.com.ubo.tp.message.ihm.*;
import main.java.com.ubo.tp.message.ihm.session.ISession;

import java.util.HashSet;
import java.util.Objects;
import java.util.UUID;

public class ConnexionController implements ConnexionView.ConnexionListener {
    protected IDatabase database;
    protected EntityManager entityManager;
    protected ISession session;

    protected ConnexionView connexionView;

    public ConnexionController(ConnexionView connexionView, IDatabase database, EntityManager entityManager, ISession mSession) {
        connexionView.loginOnClick(this);
        this.database = database;
        this.entityManager = entityManager;
        this.session = mSession;
    }

    @Override
    public void loginOnClick(String username, String tag) {
        initFolder();
        User userWhoWantsToLogin = userFromUsernameAndPassword(username, tag);
        Boolean EstPresent = false;
        for(User user : database.getUsers()){
            if(Objects.equals(user.getUserTag(), userWhoWantsToLogin.getUserTag())){
                EstPresent = true;
            } else {
                EstPresent = false;
            }
        }
        if(EstPresent == true){
            session.connect(userWhoWantsToLogin);
            System.out.println("L'utilisateur " + session.getConnectedUser().getUserTag() + " est connecté!");
            //this.connexionView.removeAll();
            //new MessageApp(database,entityManager,session).initAccueil();
            new AccueilController(database,entityManager, session);

        }else{
            System.out.println("L'utilisateur " + userWhoWantsToLogin.getUserTag() + " est inexistant !");
        }
    }

    @Override
    public void RegisterOnClick(String text, String text1) {

    }

    public User userFromUsernameAndPassword(String username, String tag){
        return new User(UUID.randomUUID(), tag, "",username, new HashSet<>(), "");
    }

    public void initFolder(){
        entityManager.setExchangeDirectory("src/main/resources/users/");
    }

}
