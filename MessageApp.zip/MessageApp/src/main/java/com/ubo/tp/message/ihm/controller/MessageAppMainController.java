package main.java.com.ubo.tp.message.ihm.controller;

public class MessageAppMainController {
}
