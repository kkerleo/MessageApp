// AccueilView.java
package main.java.com.ubo.tp.message.ihm;

import main.java.com.ubo.tp.message.datamodel.User;
import main.java.com.ubo.tp.message.ihm.controller.AccueilController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;

public class AccueilView {
    protected JFrame mFrame;
    protected JList<String> messageList;
    protected DefaultListModel<String> messageListModel;
    protected JList<String> userList;
    protected DefaultListModel<String> userListModel;

    protected AccueilController accueilController;

    public AccueilView(AccueilController controller) {
        this.accueilController = controller;
        fenetreMenuPopupGUI();
    }

    private void fenetreMenuPopupGUI() {
        Dimension dimension = new Dimension(900, 450);
        ImageIcon imageIcon = new ImageIcon("src/main/resources/images/logo_20.png");

        this.mFrame = new JFrame("Fenetre");
        this.mFrame.setLayout(new BorderLayout());
        this.mFrame.setPreferredSize(dimension);
        this.mFrame.setIconImage(imageIcon.getImage());

        // Menu Bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fichierMenu = new JMenu("Fichier");
        JMenu autreMenu = new JMenu("?");

        JMenuItem ouvrirMenuItem = new JMenuItem("Ouvrir");
        ImageIcon openIcon = new ImageIcon("src/main/resources/images/editIcon_20.png");
        ouvrirMenuItem.setIcon(openIcon);
        ouvrirMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                selecteurFichier();
            }
        });
        JMenuItem quitterMenuItem = new JMenuItem("Quitter");
        ImageIcon crossIcon = new ImageIcon("src/main/resources/images/exitIcon_20.png");
        quitterMenuItem.setIcon(crossIcon);
        quitterMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        fichierMenu.add(ouvrirMenuItem);
        fichierMenu.add(quitterMenuItem);

        JFrame finalMFrame = mFrame;
        autreMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ImageIcon imageIcon = new ImageIcon("src/main/resources/images/logo_50.png");
                JLabel jLabel = new JLabel("<html><center>UBO M2-TIIL<br>Département Informatique");
                JOptionPane.showMessageDialog(finalMFrame, jLabel, "A propos", JOptionPane.INFORMATION_MESSAGE, imageIcon);
            }
        });

        menuBar.add(fichierMenu);
        menuBar.add(autreMenu);

        this.mFrame.setJMenuBar(menuBar);

        JPanel userProfilePanel = new JPanel(new BorderLayout());
        userProfilePanel.setPreferredSize(new Dimension(150, 0)); // Set the width of the panel

        JLabel userProfileLabel = new JLabel("Connected User Profile");
        JTextArea userProfileTextArea = new JTextArea();

        User connectedUser = accueilController.getConnectedUser();
        if (connectedUser != null) {
            userProfileTextArea.append("Name: " + connectedUser.getName() + "\n");
            userProfileTextArea.append("User Tag: " + connectedUser.getUserTag() + "\n");
        }

        userProfilePanel.add(userProfileLabel, BorderLayout.NORTH);
        userProfilePanel.add(new JScrollPane(userProfileTextArea), BorderLayout.CENTER);

        this.mFrame.add(userProfilePanel, BorderLayout.WEST);

        userListModel = new DefaultListModel<>();
        userList = new JList<>(userListModel);
        JScrollPane userScrollPane = new JScrollPane(userList);

        // Message List
        messageListModel = new DefaultListModel<>();
        messageList = new JList<>(messageListModel);
        JScrollPane messageScrollPane = new JScrollPane(messageList);

        // SplitPane to display users on the left and messages on the right
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, userScrollPane, messageScrollPane);
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(150); // Adjust the width of the user area as needed

        JTextField rechercheTextField = new JTextField(20);
        JButton rechercheButton = new JButton("Rechercher");

        rechercheButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String rechercheText = rechercheTextField.getText();
                accueilController.rechercherUtilisateur(rechercheText);
            }
        });

        JPanel recherchePanel = new JPanel(new FlowLayout());
        recherchePanel.add(new JLabel("Rechercher Utilisateur: "));
        recherchePanel.add(rechercheTextField);
        recherchePanel.add(rechercheButton);

        this.mFrame.add(recherchePanel, BorderLayout.NORTH);
        this.mFrame.add(splitPane, BorderLayout.CENTER);

        this.mFrame.pack();
        this.mFrame.setLocationRelativeTo(null);
        this.mFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.mFrame.setVisible(true);
    }

    public void ajouterUtilisateurs(List<String> utilisateurs) {
        userListModel.clear();
        for (String utilisateur : utilisateurs) {
            userListModel.addElement(utilisateur);
        }
    }

    public void ajouterMessage(String message) {
        messageListModel.addElement(message);
    }

    public void setUserList(JList<String> userList) {
        this.userList = userList;
    }

    public void setMessageList(JList<String> messageList) {
        this.messageList = messageList;
    }

    protected void selecteurFichier() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Ouvrir");
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        int result = fileChooser.showOpenDialog(mFrame);

        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            ajouterMessage("Fichier sélectionné : " + selectedFile.getAbsolutePath());
        } else {
            ajouterMessage("Aucun fichier sélectionné");
        }
    }
}
