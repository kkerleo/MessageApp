// AccueilController.java
package main.java.com.ubo.tp.message.ihm.controller;

import main.java.com.ubo.tp.message.core.EntityManager;
import main.java.com.ubo.tp.message.core.database.IDatabase;
import main.java.com.ubo.tp.message.datamodel.User;
import main.java.com.ubo.tp.message.ihm.AccueilView;
import main.java.com.ubo.tp.message.ihm.session.ISession;

import javax.swing.*;
import java.util.Collections;

public class AccueilController {
    protected IDatabase database;
    protected EntityManager entityManager;
    protected ISession session;

    protected AccueilView accueilView;

    public AccueilController(IDatabase database, EntityManager entityManager, ISession mSession) {
        this.database = database;
        this.entityManager = entityManager;
        this.session = mSession;
        this.accueilView = new AccueilView(this);
        recupererUtilisateurs();
        //recupererMessages();
    }

    private void recupererUtilisateurs() {
        DefaultListModel<String> userListModel = new DefaultListModel<>();
        JList<String> userList = new JList<>(userListModel);
        for (User user : database.getUsers()) {
            userListModel.addElement(user.getName() + " - " + user.getUserTag());
        }

        //accueilView.setUserList(userList);
    }

    public User getConnectedUser() {
        return session.getConnectedUser();
    }

    public void rechercherUtilisateur(String rechercheText) {
        for (User user : database.getUsers()) {
            if (user.getUserTag().contains(rechercheText) || user.getName().contains(rechercheText)) {
                accueilView.ajouterUtilisateurs(Collections.singletonList(user.getName() + " - " + user.getUserTag()));
            }
        }
    }
}
